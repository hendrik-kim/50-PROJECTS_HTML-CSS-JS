import React from 'react';
import styled from 'styled-components';

function Modify() {
  return <Container>Modify</Container>;
}

const Container = styled.div``;

export default Modify;
