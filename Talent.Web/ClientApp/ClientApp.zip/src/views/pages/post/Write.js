import React from 'react';
import styled from 'styled-components';

function Write() {
  return <Container>Write</Container>;
}
 
const Container = styled.div``;

export default Write;
